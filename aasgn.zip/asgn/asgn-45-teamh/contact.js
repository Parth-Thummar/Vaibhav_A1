export class Contact {
    constructor(name, email, tel, address, geoData=[null,null,null], weatherData = [null, null, null]){
        this.name = name
        this.email = email
        this.tel = tel
        this.address = address
        this.geoData = geoData;
        this.weatherData = weatherData;
    }
}