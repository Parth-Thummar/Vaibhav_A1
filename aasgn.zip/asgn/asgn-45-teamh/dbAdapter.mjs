import { MongoClient } from 'mongodb';
import { Contact } from './contact.js'

const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);
var db;

/**
 * A function to stablish a connection with a MongoDB instance.
 */
export async function initStore(cSetName = 'contacts') {
    try {
        // Connect the client to the server
        await client.connect();
        // Our db name is going to be contacts-db
        db = await client.db('contacts-db');
        console.log("Connected successfully to mongoDB");

        // set a connection timeout
        setTimeout( () => client.close(), 5000 )

    } catch (err) {
        throw err;
    }

    return await db.collection(cSetName);
}

async function _get_contacts_collection(cSetName) {
    // Connect the client to the server
    await client.connect();
    // Our db name is going to be contacts-db
    db = await client.db('contacts-db');
    // console.log("Connected successfully to mongoDB");  
    return await db.collection(cSetName);
};

async function _close_collection() {
    // await client.close();
    // return 'Connection closed';
};

async function closeStore(cSetName) {
    await client.close();
    return 'Connection closed';
};

async function addContact(cSetName, c) {
    let collection = await _get_contacts_collection(cSetName);
    let mongoObj = await collection.insertOne(c);
    console.log('1 Contact was inserted in the database with id -> ' + mongoObj.insertedId);
    _close_collection();
    return true;

}

async function delContact(cSetName, who) {
    let collection = await _get_contacts_collection(cSetName);
    let obj = await collection.deleteOne({ 'name': who })
    _close_collection();
    if (obj.deletedCount > 0) {
        return 'Contact was deleted.'
    } else {
        throw new Error(`${who} not found`)
    }
}

async function updateContact(cSetName, who, c) {
    let collection = await _get_contacts_collection(cSetName);
    let new_vals = { $set: { 'name': c.name, 'email': c.email, 'tel': c.tel, 'address': c.address } };
    let obj = await collection.updateOne({ 'name': who }, new_vals)
    _close_collection();
    if (obj.modifiedCount > 0) {
        return 'Contact correctly updated.';
    } else {
        throw new Error(`${who} not found`)
    }
}

async function findContact(cSetName, who = null) {
    let collection = await _get_contacts_collection(cSetName);
    let findspec = {};
    if (who) findspec = { "name": who };
    let objs = await collection.find(findspec).toArray();
    _close_collection();
    return objs.map(o => new Contact(o.name,o.email,o.tel,o.address, o.geoData, o.weatherData));
}


export default { closeStore, initStore, addContact, delContact, updateContact, findContact }