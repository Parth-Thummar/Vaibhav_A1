# Assignment 5 update - due Oct 10, 2024

This update include a unit test file that will be used to grade your assignment 4 and 5 submission. Note we are covering unit testing topic this week.

The updates include:
.
├── doc
│   ├── Assignment5_update.md
├── endpoints.js (modified)
└── tests
    └── test-app.mjs

*endpoints.js* has been modified to skip the use of the geomapping service (to speed up testing) and correct a bug on line 62 by adding an *await*. You should be able to substitute this version in your code since you do not have to modify endpoints in the assignment. 