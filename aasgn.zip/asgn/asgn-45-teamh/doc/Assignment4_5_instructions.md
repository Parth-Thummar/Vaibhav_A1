# Assignment 4_5 - due Oct 10, 2024

This is a combined assignment which counts double (4%) for your grade.
This assignment will focus on understanding alternate implementations of an interface in javascript. 
This is crucial for software design principles of
separation of concerns, reducing dependency, reduced coupling, and the SRP, OCP, and ISP of SOLID.  
It will also show use of a module interface in javascript. 

## Instructions

Hold a team meeting in which each team member is assigned a different persistence technology to be
applied to this assignment. Your technology choices are listed in the next section. Make sure the decisions about your implementation are
reported in your team meetings notes, appearing in the main branch of the team's project repo. Also include a description of each member's implementation in the README.md on the main branch of this assignment's repo.

Each team member is to complete a *different* implementation of the persist methods exported from the persist interface. 

    export default { closeStore, initStore, addContact, delContact, updateContact, findContact }

In addition to the stub implementation in persist.js, there is a local Mongo implementation in dbAdapter.js

Unit tests for the assignment will be provided to check your implementation.

Provide the attributions table on your branch as appropriate.

**Submit** by pushing your solution to your own branch on the assignment github repo by the due date.  

## The programming problem

The signature and semantics (the *interface*) for the persist methods that you must implement should be clear from the stub implementation provided.

Here are your choices for technology to implement your persistence solution:

1. plain text files on the local server host using standard file operations. See the javascript fs module for details [tutorial](https://nodejs.org/docs/latest-v20.x/api/fs.html).
2. Using a nodejs [sqlite3 library](https://www.npmjs.com/package/sqlite3), an SQL database file can be opened and used on the server host without starting up an sql server.as shown in this [tutorial](https://www.sqlitetutorial.net/sqlite-nodejs/)
3. [Mongo](https://www.mongodb.com) has a remote database service running *atlas* which you can set up with very little change to the solution code I provided - if you are willing to get a free account with them.
4. Use a local-storage solution design to emulate a similar client javascript package. This node install is available [on the npm site](https://www.npmjs.com/package/node-localstorage)
5. Another local storage solution is the npm package [store2] (https://www.npmjs.com/package/store2)
6. If you are familiar with another database technology, just check with the instructor to see if you can use it.