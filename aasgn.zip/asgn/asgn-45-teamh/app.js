/**
 * @author Amilcar Soares
 * @version 2.0 
 * Date: January 19, 2022
 * This application provides a text-file contact
 * app that can query third-party services to gather
 * location and weather information from the contact's
 * address. In this application you will see several
 * code examples on how to work with Promises, Promise.race,
 * Promise.all and async-await syntax.
 * 
 * Modified E Brown F24
 **/ 

import express, { json, urlencoded } from 'express';
import { contacts_init, list_all, get_contact, add, update_contact, delete_contact } from './endpoints.js';
const app = express();


app.use(express.json());// support json encoded bodies
app.use(express.urlencoded({extended: true}));//incoming objects are strings or arrays

contacts_init();// init the contacts connection

// contacts resource paths
app.get('/contacts', list_all);
app.get('/contacts/:name', get_contact);
app.post('/contacts', add);
app.put('/contacts/:name', update_contact);
app.delete('/contacts/:name', delete_contact);

app.on('close', () => console.log("CLOSING"))


export default app // useful when started as a module
