import persist from './dbAdapter.mjs';
// import persist from './persist.js'
import { Contact } from './contact.js';
import { getGeoLocation } from './get-geo-data.js';
import { getWeatherData } from './get-weather-data.js';
import v from './validate-fields.js';
/**
 * A simple function to delete the file if it exists.
 */
export function contacts_init() {
    persist.initStore('store1')
};

/**
 * A function that adds a contact to the store.
 * The function creates a contact with a CSV-like style and appends
 * to the file. 
 * The function now is able to download data from three different
 * third-party APIs and will include contact's lat, lon, source,
 * as well as climatological data from the user's location 
 * @param {Request} req -  HTTP Request Object
 * @param {*} res 
 */

export async function add(req, res) {
    let name = req.body.name;
    let email = req.body.email;
    let tel = req.body.tel;
    let address = req.body.address;
    
    try {
        // if next promise fails, it will be redirected to the catch
        let validFields = await v.validate_fields(name, email, tel, address);
        // it will come here only if promise is runs with no problems
        let new_contact = new Contact(name, email, tel, address);
        // Let's retrieve user's geocoding information
        let geoData = null;
        /* for testing purposes, geodata has been disabled      
        try {
            geoData = await getGeoLocation(address);
            new_contact.geoData = [geoData[0], geoData[1], geoData[2]];
        } catch (err) {
            new_contact.geoData = [null, null, null];
        } 

        // we will need the geographic info to download weather data.
        // therefore, we only proceed if geoData is not null
         if (geoData) {
            try {
                let weatherData = await getWeatherData(geoData[0], geoData[1]);
                new_contact.weatherData = [weatherData.temp, weatherData.feels_like, weatherData.humidity];
            } catch (err) {
                console.log(err);
                // add something to the object if an error occurs
                new_contact.weatherData = [null, null, null];
            }
        } else {
            // do the same if geographic coordinates not available
            new_contact.geoData = ['no data found', null, null];
        } 
        */
        await persist.addContact('store1', new_contact);
        res.send('User correctly added.');
    } catch (err) {
        // sends the error from the user's data that are invalid
        console.log(err);
        res.send('' + err);
    }
};

/**
 * A function that lists all contacts with all information that is
 * in the store. 
 * @param {*} req 
 * @param {*} res 
 */
export async function list_all(req, res) {
    let data = await persist.findContact('store1')
    res.send(data);
};

/**
 * A function that gets a contact by name and returns all
 * data of the requested contact. 
 * @param {*} req 
 * @param {*} res 
 */
export async function get_contact(req, res) {
    let name_to_match = req.params.name;
    try {
        let contact = await persist.findContact('store1', name_to_match);
        res.send(contact);
    } catch {
        let msg = 'The user ' + name_to_match + ' was not found.';
        res.send(msg);
    }
};

/**
 * A function to update the information about a given contact.
 * @param {*} req 
 * @param {*} res 
 */
export async function update_contact(req, res) {
    let update_contact = new Contact(req.body.name, req.body.email, req.body.tel, req.body.address);
    try {
        let result = persist.updateContact('store1', req.params.name, update_contact)
        res.send('Contact correctly updated.');
    } catch {
        let msg = 'The user ' + req.params.name + ' was not found.';
        res.send(msg);
    }
};

/**
 * A function that deletes the information about a given contact.
 * @param {*} req 
 * @param {*} res 
 */
export async function delete_contact(req, res) {
    let name_to_match = req.params.name;
    try {
        let result = persist.delContact('store1', name_to_match)
        res.send('Contact correctly deleted.');
    } catch {
        let msg = 'The user ' + name_to_match + ' was not found.';
        res.send(msg);
    }
};
