/* A module to mock or stub interface for persistance on Contacts information.
   It only stores data in a non-persistent list.
   */

var contactList = []

function initStore(cSetName) {

}

function closeStore(cSetName) {

}

function addContact(cSetName, c) {
    contactList.push(c)
    return true
}

function delContact(cSetName, who) {
    for (let index in contactList)
        if (contactList[index].name === who) {
            contactList.splice(index, 1)
            return 'Contact was deleted.'
        }
    throw new Error(`${who} not found`)
}

function updateContact(cSetName, who, c) {
    for (let index in contactList)
        if (contactList[index].name === who) {
            contactList[index] = c
            return 'Contact correctly updated.'
        }
    throw new Error(`${who} not found`)
}

function findContact(cSetName, who = null) {
    if (who) {
        for (let index in contactList)
            if (contactList[index].name === who) {
                return [contactList[index]]
            }
        throw new Error(`${who} not found`)
    }
    return contactList

}

export default { closeStore, initStore, addContact, delContact, updateContact, findContact }