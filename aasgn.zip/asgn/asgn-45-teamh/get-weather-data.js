/**
 * @author Amilcar Soares
 * @version 1.0 
 * Date: January 19, 2022
 * This script contains a function based on lat and lon
 * will download weather information about a location.
 * 
 * Changed to async/fetch by E Brown 2024
 */


/**
 * Requests Weather data in the OpenWeatherMap API
 * @param {Number} lat Latitude
 * @param {Number} lng Longitude
 */
export async function getWeatherData(lat, lng) {
    let url = 'http://api.openweathermap.org/data/2.5/weather'
    let key = 'c95f697b42b184d0194c29bc8ac44641';
    let weatherResponse = await fetch(url + "?lat=" + lat + "&lon=" + lng + "&units=metric&appid=" + key)
    return (await weatherResponse.json()).main
}


