import assert from 'assert';
import request from 'supertest';
import app from '../app.js'
import { describe, suite, test, beforeEach, after } from 'node:test';

let test_data = [// Adding a new user
    {
        name: 'Amilcar Soares',
        email: 'amilcarsj@mun.ca',
        tel: '709-456-7891',
        address: '230 Elizabeth Ave, St. John\'s, Newfoundland'
    },

    // Adding another user
    {
        name: 'John Smith',
        email: 'jsmith@mun.ca',
        tel: '709-456-7891',
        address: '235 Forest Road, St. John\'s, Newfoundland'
    },
    // Adding another one
    {
        name: 'Bob Churchil',
        email: 'bchurchil@mun.ca',
        tel: '709-987-6543',
        address: '50 Crosbie Road, St. John\'s, Newfoundland'
    }
]

function adjustClosure(){ // adjust the names prior to posting will ensure unique data
    let calls = 0
    const tag = (new Date()).valueOf() // unique each run
    return function (){
        test_data.forEach(t => { 
            let splits = t.name.split(' ').slice(0,1)
            splits.push(tag,calls++)
            t.name = splits.join(' ')
        })
    }

}
const adjustnames = adjustClosure()

suite('Test API calls with supertest', function () {
    
    /**
     * We should be able to create new test data entries in the DB for our tests
     * and clear it up "after()" - but the existing API will not allow this conveniently
     * 
     * Some apps will have a "hidden" test API with a few extra calls for testing purposes.
     * 
     * Another even better approach is to use a test database, and delete or clean it "after()", 
     * the current API does not allow us to pick the database
     * 
     * Instead we just mess with the data for each test.
     */
    beforeEach(adjustnames)

    after(() => {
        console.log("The test data has to be cleaned up manually - it has not been automated.")})

    test('Posts new user info', async function () {
        // to make multiple API calls using the same session cookie, create a server agent for one app run
        let server_agent = request.agent(app)

        //post the data
        let response = await server_agent.post('/contacts').send(test_data[0])
        assert.strictEqual(response.text, 'User correctly added.')
        response = await server_agent.post('/contacts').send(test_data[1])
        assert.strictEqual(response.text, 'User correctly added.')
        response = await server_agent.post('/contacts').send(test_data[2])
        assert.strictEqual(response.text, 'User correctly added.')
    })

    test('Get some contacts GET /contacts', async function () {
        let server_agent = request.agent(app)

        //post the data
        let response = await server_agent.post('/contacts').send(test_data[0])
        assert.strictEqual(response.text, 'User correctly added.')
        response = await server_agent.post('/contacts').send(test_data[1])
        assert.strictEqual(response.text, 'User correctly added.')
        response = await server_agent.post('/contacts').send(test_data[2])
        assert.strictEqual(response.text, 'User correctly added.')

        // retreive the data
        let respo = await server_agent.get('/contacts')
        assert(respo.body.length > 0, 'Error. No data retreived.');
        
        respo = await server_agent.get('/contacts/' + test_data[0].name)
        assert.strictEqual(respo.body[0].tel, test_data[0].tel)
        respo = await server_agent.get('/contacts/' + test_data[1].name)
        assert.strictEqual(respo.body[0].tel, test_data[1].tel)
        respo = await server_agent.get('/contacts/' + test_data[2].name)
        assert.strictEqual(respo.body[0].tel, test_data[2].tel)

    })

    test(`Delete`, async function () {

        let server_agent = await request.agent(app)

        //post the data
        let response = await server_agent.post('/contacts').send(test_data[1])
        assert.strictEqual(response.text, 'User correctly added.')

        response = await server_agent.delete('/contacts/' + test_data[1].name)
        assert.strictEqual(response.text, 'Contact correctly deleted.')



    });

    test(`Update`, async function () {

        let server_agent = await request.agent(app)

        //post the data
        let response = await server_agent.post('/contacts').send(test_data[0])
        assert.strictEqual(response.text, 'User correctly added.')

        test_data[0].address = "123 New Address Rd, Newtown, New FoundLand"
        response = await server_agent.put('/contacts/' + test_data[0].name).send(test_data[0])
        assert.strictEqual(response.text, 'Contact correctly updated.')

    });

})
