var myurl = 'http://localhost:3000';

async function getData(){
    try{
        let res = await fetch(myurl + '/contacts', { signal: AbortSignal.timeout(1000)})
        console.log('Listing all contacts')
        console.log(await res.text())

        res = await fetch(myurl + '/contacts/Amilcar Soares', { signal: AbortSignal.timeout(1000)})
        console.log('Listing one contact')
        console.log(await res.text())

        res = await fetch(myurl + '/contacts/Bad Data', { signal: AbortSignal.timeout(1000)})
        console.log(await res.text())

    }catch(err){
        console.log('ERROR: '+err)
    }
}

getData();
