import assert from 'assert';
import persist from '../persist.js'
import { before, suite, test, beforeEach, afterEach, after } from 'node:test';

let test_data = [// Adding a new user
    {
        name: 'Amilcar Soares',
        email: 'amilcarsj@mun.ca',
        tel: '709-456-7891',
        address: '230 Elizabeth Ave, St. John\'s, Newfoundland'
    },

    // Adding another user
    {
        name: 'John Smith',
        email: 'jsmith@mun.ca',
        tel: '709-456-7891',
        address: '235 Forest Road, St. John\'s, Newfoundland'
    },
    // Adding another one
    {
        name: 'Bob Churchil',
        email: 'bchurchil@mun.ca',
        tel: '709-987-6543',
        address: '50 Crosbie Road, St. John\'s, Newfoundland'
    }
]

function adjustClosure(){ // adjust the names prior to posting will ensure unique data
    let calls = 0
    const tag = (new Date()).valueOf() // unique each run
    return function (){
        test_data.forEach((e,i,a) => { 
            a[i] = {
                name: e.name + " " + tag + " " + calls++,
                email: e.email,
                tel : e.tel,
                address: e.address
            }
        })
    }

}
const changeData = adjustClosure()

suite('Test persist calls', function () {
    
    /**
     * We should be able to create new test data entries in the DB for our tests
     * and clear it up "after()" - but the existing API will not allow this conveniently
     * 
     * Some apps will have a "hidden" test API with a few extra calls for testing purposes.
     * 
     * Another even better approach is to use a test database, and delete or clean it "after()", 
     * the current API does not allow us to pick the database
     * 
     * Instead we just mess with the data for each test.
     */
    beforeEach(changeData)
    before(() => persist.initStore('testStore'))
    after(() => {
        persist.closeStore();
        console.log("The test data has to be cleaned up manually - it has not been automated.")
    })

    test('addContact', async function () {

        await persist.addContact('testStore', test_data[0]);
        await persist.addContact('testStore', test_data[1]);
        await persist.addContact('testStore', test_data[2]);
    })

    test('findContact', async function () {

        await persist.addContact('testStore', test_data[0]);
        await persist.addContact('testStore', test_data[1]);
        await persist.addContact('testStore', test_data[2]);

        let contacts = await persist.findContact('testStore', test_data[0].name);
        assert.strictEqual(contacts[0].address, test_data[0].address, 'bad address.');
        contacts = await persist.findContact('testStore', test_data[1].name);
        assert.strictEqual(contacts[0].address, test_data[1].address, 'bad address.');
        contacts = await persist.findContact('testStore', test_data[2].name);
        assert.strictEqual(contacts[0].address, test_data[2].address, 'bad address.');
    })

    test(`Delete`, async function () {

        await persist.addContact('testStore', test_data[1]);

        let response = await persist.delContact('testStore', test_data[1].name)
        assert.strictEqual(response, 'Contact was deleted.')

    });

    test(`Update`, async function () {

        await persist.addContact('testStore', test_data[0]);

        test_data[0].address = "123 New Address Rd, Newtown, New FoundLand"
        let response = await persist.updateContact('testStore', test_data[0].name, test_data[0])
        assert.strictEqual(response, 'Contact correctly updated.')

    });

})
