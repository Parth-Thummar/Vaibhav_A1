
var myurl = 'http://localhost:3000';


async function updateDelete(){
    let res = await fetch(myurl + '/contacts/Amilcar Soares', {
                    method: "PUT",
                    body: JSON.stringify({
                            name: 'Amilcar Soares', 
                            email: 'amilcarsj@mun.ca', 
                            tel: '709-221-4567', 
                            address: 'My new address at St. Johns updated'
                    }),
                    headers: {'content-type': 'application/json'},
                    signal: AbortSignal.timeout(3000)    
    });
    console.log(await res.text());

    res = await fetch(myurl + '/contacts/Bob Churchil', {
        method: "DELETE",
        signal: AbortSignal.timeout(1000) 
    });
    console.log(await res.text());
}
updateDelete();