
var myurl = 'http://localhost:3000';

// Configure the fetch options
const postOptions = dataPayload => {
    return {
        method: "POST",
        body: JSON.stringify(dataPayload),
        headers: {'content-type': 'application/json'},
        signal: AbortSignal.timeout(3000)
    }
};

// Adding a new user
var data1 = {
    name: 'Amilcar Soares', 
    email: 'amilcarsj@mun.ca', 
    tel: '709-456-7891', 
    address: '230 Elizabeth Ave, St. John\'s, Newfoundland'
};

// Adding another user
var data2 = {
    name: 'John Smith', 
    email: 'jsmith@mun.ca', 
    tel: '709-456-7891', 
    address: '235 Forest Road, St. John\'s, Newfoundland'
};
// Adding another one
var data3 = {
    name: 'Bob Churchil', 
    email: 'bchurchil@mun.ca', 
    tel: '709-987-6543', 
    address: '50 Crosbie Road, St. John\'s, Newfoundland'
};
// Here we add the three new objects, one after the other
async function post_objects(){
    try{
        let res = await fetch(myurl + '/contacts', postOptions(data1))
        console.log(await res.text());
        res = await fetch(myurl + '/contacts', postOptions(data2))
        console.log(await res.text());
        res = await fetch(myurl + '/contacts', postOptions(data3))
        console.log(await res.text());
    }catch(err){
        console.log(err)
    }
    
}
post_objects();

