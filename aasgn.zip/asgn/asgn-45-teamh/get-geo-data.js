
/**
 * @author Amilcar Soares
 * @version 1.0 
 * Date: January 19, 2022
 * This script contains functions that will get 
 * geocoding locations (lat, lon) based on an address
 * given by the user. Since we have two services available
 * that provide the same information, we make them
 * compete using Promise.race. 
 * 
 * Changed to fetch API E Brown 2024
 */


// Geocoding based on users address

/**
 * Requests the Geolocation of a contact based on the address provided.
 * This request is done in the MapQuestAPI
 * @param {String} address: The contact's address
 */
var getAddressMapQuestAPI = async (address) => {
	let url = 'https://www.mapquestapi.com/geocoding/v1/address';
	let key = 'izHLmTfmzDtxR78L5l9Nh14kjiyiwkN5';
	//let response = await get(url+"?key="+key+"&location="+address)
	let response = await fetch(url+"?key="+key+"&location="+address, { method: "GET" })
	let value = await response.json()
	
	let lat = value.results[0].locations[0].latLng.lat;
	let lng = value.results[0].locations[0].latLng.lng;
	return [lat, lng, 'MapQuest'];
};
/**
 * Requests the Geolocation of a contact based on the address provided.
 * This request is done in the PositionStack API
 * @param {String} address: The contact's address
 */
var getAddressPositionStackAPI = async (address) => {
		let url = 'http://api.positionstack.com/v1/forward'
		let key = '0d2fbf39cb90ac6cd5267076d7b2afb0';
		let response = await fetch(url+"?access_key="+key+"&query="+address)
		let value = await response.json()
		let lat = value.data[0].latitude;
		let lng = value.data[0].longitude;
		return [lat, lng, 'PositionStack'];	
};

/**
 * This function creates a promise race between the two Geocoding providers.
 * @param {String} address: The contact's address.
 * 
 * Deleted PositionStack from race due to no working key. 2024
 */
export async function getGeoLocation(address) {

	return await Promise.race([getAddressMapQuestAPI(address)])

}

